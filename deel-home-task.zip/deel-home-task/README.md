# deel-home-task

> Take home task from deel.

## Things I did 

- Added `jest` test framework using `supertest` so I could cover endpoint in tests - I hadn't used `supertest` before but seemed a quick option to be able to fully test the API 
- Created a Postman collection for adhoc manual testing
- Implemented the first few endpoints - really wanted to make sure I got to do a `POST` one
- Hard to tell, but probably spend more than 3 hours total across several smaller sessions, but did need to use `sequelize` documentation quite a bit

## Things I wanted to do next

- Try and get the `Job` `paymentDate` updated automatically when `paid` is set to `true`
- Implement the other routes I didn't manage to get round to implementing (I may do this in my own time for my own learning anyway)
- Think about restructuring into more manageable layers and possibly move some things up into middleware too (I think I'll also do this as well)

## Notes

- I generally ran out of time - I don't think I will be able to perform at a pace like this without a lot more practice
- I hadn't used `sequelize`, `sqlite` or `supertest` before - so it was good to have an opportunity to try those! I spent quite a bit of time with the `sequelize` documentation during the task!
- I should have planned better to better structure to begin with - I think I felt a bit rushed by the amount of things to implement in time I had so just made a start
- I should have read the `README` more thoroughly as I may have committed differently (in smaller increments with better messages) had I remembered that `.git` was to be submitted also, I probably would have used [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/) like I normally do at work rather than less verbose commits like I might in personal projects
