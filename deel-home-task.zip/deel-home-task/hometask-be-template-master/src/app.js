const express = require('express');
const bodyParser = require('body-parser');
const { Op } = require('sequelize');

const {sequelize} = require('./model')
const {getProfile} = require('./middleware/getProfile')

const app = express();

app.use(bodyParser.json());
app.set('sequelize', sequelize)
app.set('models', sequelize.models)

/**
 * GET /contracts/:id
 * @returns contract by id
 */
app.get('/contracts/:id',getProfile ,async (req, res) =>{
    const {Contract} = req.app.get('models')
    const {id} = req.params
    const contract = await Contract.findOne({where: {id}})
    if(!contract) return res.status(404).end()
    if(contract.ClientId !== req.profile.id && contract.ContractorId !== req.profile.id) {
        return res.status(403).send('Not authorized to view that Contract')
    }
    res.json(contract)
})

/**
 * GET /contracts
 * @returns all non-terminated contracts belonging to a user
 */
app.get('/contracts',getProfile ,async (req, res) =>{
    const {Contract} = req.app.get('models')
    const { id, type } = req.profile
    const contracts = await Contract.findAll({
        where: type === 'client'
            ? { ClientId: id, status: { [Op.not]: "terminated" } }
            : { ContractorId: id, status: { [Op.not]: "terminated" } }
    })
    if(!contracts) return res.status(404).end()
    res.json(contracts)
})


/**
 * GET /jobs/unpaid
 * @returns all unpaid active jobs for a user
 */
app.get('/jobs/unpaid',getProfile ,async (req, res) =>{
    const {Contract, Job} = req.app.get('models')
    const { id, type } = req.profile
    const contractJobs = await Job.findAll({
        include: {
            model: Contract,
            required: true,
            where: type === 'client'
                ? { ClientId: id, status: { [Op.not]: "terminated" }}
                : { ContractorId: id, status: { [Op.not]: "terminated" }}
        },
        where: {
            paid: {[Op.not]: true }
        }
    })
    if(!contractJobs) return res.status(404).end()
    res.json(contractJobs)
})

/**
 * GET /jobs/:job_id/pay
 * @returns the new balance for the client
 */
app.post('/jobs/:job_id/pay',getProfile ,async (req, res) =>{
    const {Contract, Job, Profile} = req.app.get('models')
    const { id, balance } = req.profile
    const { job_id } = req.params

    const job = await Job.findOne({where: {id: job_id}})
    if (!job) return res.status(404).send('Job not found')

    // if not client for contract calling to pay then return
    const contract = await Contract.findOne({where: {id: job.ContractId}})
    if (id !== contract.ClientId) return res.status(403).end('Not authorized')

    // if client cannot afford to pay job balance then return
    if (balance < job.price) return res.status(202).send(`Insufficient balance (${balance}) to pay for job with cost ${job.price}`)

    // if job is already paid
    if (job.paid) return res.status(202).send(`Job ${job.id} already paid on ${job.paymentDate}`)

    const newClientBalance = balance - job.price
    try {
        // try and make all the necessary updates in a transaction
        await sequelize.transaction(async (t) => {
            // reduce client's balance by job cost
            await Profile.update({balance: newClientBalance}, {where: {id}, transaction: t})
            // increase contractor's balance by job cost
            await Profile.increment({balance: job.price}, {where: {id: contract.ContractorId}, transaction: t})
            // mark the job as done and set the payment date
            await job.update({ paid: true }, {transaction: t})
        })
        return res.status(200).json({ balance: newClientBalance, job_id: job.id })
      } catch (error) {
        return res.status(500).send('An error occurred during payment')
      }
})

module.exports = app;
