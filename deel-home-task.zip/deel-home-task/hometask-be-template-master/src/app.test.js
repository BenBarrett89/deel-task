const request = require('supertest')
const { Op } = require('sequelize')

const app = require('./app')
const model = require('./model')

describe('No headers', () => {
  it('should return unauthorised when no profile_id header is passed', async () => {
    await request(app)
      .get('/contracts/whatever')
      .expect(401)
  })
})

describe('GET /contracts/:id', () => {
  it('should return the contract if the contract is owned by the profile calling the endpoint (client)', async () => {
    const response = await request(app)
      .get('/contracts/1')
      .set('profile_id', 1)
      .expect('Content-Type', /json/)
      .expect(200)

    expect(response.body).toMatchObject({
      id:1,
      terms: 'bla bla bla',
      status: 'terminated',
      ClientId: 1,
      ContractorId: 5
    })
  })

  it('should return the contract if the contract is owned by the profile calling the endpoint (contractor)', async () => {
    const response = await request(app)
      .get('/contracts/1')
      .set('profile_id', 5)
      .expect('Content-Type', /json/)
      .expect(200)

    expect(response.body).toMatchObject({
      id:1,
      terms: 'bla bla bla',
      status: 'terminated',
      ClientId: 1,
      ContractorId:5
    })
  })

  it('should return 403 if the contract does not belong to the profile calling the endpoint', async () => {
    await request(app)
      .get('/contracts/1')
      .set('profile_id', 3)
      .expect(403)
  })
})

describe('GET /contracts', () => {
  it('should return a list of non-terminated contracts belonging to a client user (single)', async () => {
    const response = await request(app)
      .get('/contracts')
      .set('profile_id', 1)
      .expect(200)
    
    expect(response.body).toMatchObject([
      {
        id:2,
        terms: 'bla bla bla',
        status: 'in_progress',
        ClientId: 1,
        ContractorId: 6
      }
    ])
  })

  it('should return a list of non-terminated contracts belonging to a client user (multiple)', async () => {
    const response = await request(app)
    .get('/contracts')
    .set('profile_id', 4)
    .expect(200)
  
  expect(response.body).toMatchObject([
    {
      id:7,
      terms: 'bla bla bla',
      status: 'in_progress',
      ClientId: 4,
      ContractorId: 7
    },
    {
      id:8,
      terms: 'bla bla bla',
      status: 'in_progress',
      ClientId: 4,
      ContractorId: 6
    },
    {
      id:9,
      terms: 'bla bla bla',
      status: 'in_progress',
      ClientId: 4,
      ContractorId: 8
    }
  ])
  })

  it('should return a list of non-terminated contracts belonging to a contractor user (single)', async () => {
    const response = await request(app)
      .get('/contracts')
      .set('profile_id', 7)
      .expect(200)
    
    expect(response.body).toMatchObject([
      {
        id: 4,
        terms: 'bla bla bla',
        status: 'in_progress',
        ClientId: 2,
        ContractorId: 7
      },
      {
        id:6,
        terms: 'bla bla bla',
        status: 'in_progress',
        ClientId: 3,
        ContractorId: 7
      },
      {
        id:7,
        terms: 'bla bla bla',
        status: 'in_progress',
        ClientId: 4,
        ContractorId: 7
      },
    ])
  })
})

describe('GET /jobs/unpaid', () => {
  it('should get all unpaid jobs for active contracts for a client user profile calling the endpoint', async () => {
    const response = await request(app)
      .get('/jobs/unpaid')
      .set('profile_id', 1)
      .expect(200)

    expect(response.body).toMatchObject([
      {
        description: 'work',
        price: 201,
        ContractId: 2,
      }
    ])
  })

  it('should get all unpaid jobs for active contracts for a contractor user profile calling the endpoint', async () => {
    const response = await request(app)
      .get('/jobs/unpaid')
      .set('profile_id', 6)
      .expect(200)

    expect(response.body).toMatchObject([
      {
        description: 'work',
        price: 201,
        ContractId: 2,
      },
      {
        description: 'work',
        price: 202,
        ContractId: 3,
      }
    ])
  })
})

describe('POST /jobs/:job_id/pay', () => {
  it('should allow the client to pay the contractors for the job providing they have the balance', async () => {
    // set up the test
    const clientId = 1
    const contractorId = 6
    const clientInitialBalance = 1150
    const contractorInitialBalance = 1214
    await model.Profile.update({balance: clientInitialBalance}, {where: {id: clientId}})
    await model.Profile.update({balance: 1214}, {where: {id: contractorId}})

    const contract = await model.Contract.findOne({where: {ClientId: clientId, ContractorId: contractorId}})
    let job = await model.Job.findOne({where: {ContractId: contract.id, paid: {[Op.not]: true}}})

    const jobCost = job.price

    // invoke the function under test
    const response = await request(app)
      .post(`/jobs/${job.id}/pay`)
      .set('profile_id', clientId)
      .expect(200)

    // make assertions (request)
    const expectedClientBalance = clientInitialBalance - jobCost
    const expectedContractorBalance = contractorInitialBalance + jobCost
    expect(response.body.balance).toBe(expectedClientBalance)
    expect(response.body.job_id).toBe(job.id)

    // make assertions (database)
    const client = await model.Profile.findOne({where: {id: clientId}})
    const contractor = await model.Profile.findOne({where: {id: contractorId}})
    expect(client.balance).toBe(expectedClientBalance)
    expect(contractor.balance).toBe(expectedContractorBalance)
    job = await model.Job.findOne({where: {id: job.id}})
    expect(job.paid).toBe(true)

    // clean up after test
    await job.update({paid: false})
    await model.Profile.update({balance: clientInitialBalance}, {where: {id: clientId}})
    await model.Profile.update({balance: contractorInitialBalance}, {where: {id: contractorId}})
  })

  it('should return 202 when the client does not have sufficient funds to pay for the job', async () => {
    // set up the test
    const clientId = 1
    const contractorId = 6
    await model.Profile.update({balance: 0}, {where: {id: clientId}})

    const contract = await model.Contract.findOne({where: {ClientId: clientId, ContractorId: contractorId}})
    let job = await model.Job.findOne({where: {ContractId: contract.id, paid: {[Op.not]: true}}})

    const jobCost = job.price

    // invoke the function under test
    const response = await request(app)
      .post(`/jobs/${job.id}/pay`)
      .set('profile_id', clientId)
      .expect(202)

    // make assertions
    expect(response.text).toBe(`Insufficient balance (${0}) to pay for job with cost ${jobCost}`)

    // clean up after test
    await model.Profile.update({balance: 1150}, {where: {id: clientId}})
  })

  it('should return 202 when the job has already been paid', async () => {
    // set up the test
    const clientId = 1
    const contractorId = 6

    const contract = await model.Contract.findOne({where: {ClientId: clientId, ContractorId: contractorId}})
    let job = await model.Job.findOne({where: {ContractId: contract.id, paid: {[Op.not]: true}}})

    await job.update({paid: true})

    // invoke the function under test
    const response = await request(app)
      .post(`/jobs/${job.id}/pay`)
      .set('profile_id', clientId)
      .expect(202)

    // make assertions
    expect(response.text.startsWith(`Job ${job.id} already paid`)).toBeTruthy()
    // clean up after test
    await job.update({paid: false})
  })

  it('should return 403 when trying to pay for a job not owned by the caller', async () => {
    // set up the test
    const clientId = 1
    const contractorId = 6
    const notClientId = 3

    const contract = await model.Contract.findOne({where: {ClientId: clientId, ContractorId: contractorId}})
    let job = await model.Job.findOne({where: {ContractId: contract.id, paid: {[Op.not]: true}}})

    const response = await request(app)
      .post(`/jobs/${job.id}/pay`)
      .set('profile_id', notClientId)
      .expect(403)

    expect(response.text).toBe('Not authorized')
  })
})